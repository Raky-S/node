const User = require('./user');

module.exports = {
  User: User
};